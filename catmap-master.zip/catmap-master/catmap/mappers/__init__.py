from mapper_base import *
from min_resid_mapper import MinResidMapper


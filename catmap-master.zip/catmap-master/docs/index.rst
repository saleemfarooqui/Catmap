Welcome to the CatMAP documentation!
====================================

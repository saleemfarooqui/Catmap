.. CatMAP documentation master file, created by
   sphinx-quickstart on Tue Nov 25 08:51:50 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to CatMAP's documentation!
==================================

.. toctree::
   :maxdepth: 2

   installation
   tutorials/index
   topics/index
   reference/catmap
   troubleshooting/index
   troubleshooting/faq



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


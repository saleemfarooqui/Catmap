catmap.mappers package
======================

Submodules
----------

catmap.mappers.mapper_base module
---------------------------------

.. automodule:: catmap.mappers.mapper_base
    :members:
    :private-members:
    :special-members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:

catmap.mappers.min_resid_mapper module
--------------------------------------

.. automodule:: catmap.mappers.min_resid_mapper
    :members:
    :private-members:
    :special-members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: catmap.mappers
    :members:
    :private-members:
    :special-members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:

catmap.scalers package
======================

Submodules
----------

catmap.scalers.generalized_linear_scaler module
-----------------------------------------------

.. automodule:: catmap.scalers.generalized_linear_scaler
    :members:
    :private-members:
    :special-members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:

catmap.scalers.null_scaler module
---------------------------------

.. automodule:: catmap.scalers.null_scaler
    :members:
    :private-members:
    :special-members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:

catmap.scalers.scaler_base module
---------------------------------

.. automodule:: catmap.scalers.scaler_base
    :members:
    :private-members:
    :special-members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:

catmap.scalers.thermodynamic_scaler module
------------------------------------------

.. automodule:: catmap.scalers.thermodynamic_scaler
    :members:
    :private-members:
    :special-members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: catmap.scalers
    :members:
    :private-members:
    :special-members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
